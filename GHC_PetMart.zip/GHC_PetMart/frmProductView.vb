﻿Public Class frmProductView
    Private Sub frmProductView_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class