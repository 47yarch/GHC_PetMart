﻿Imports MySql.Data.MySqlClient

Public Class frmShop

    Private flpProducts As New FlowLayoutPanel()
    Private txtSearch As New TextBox()
    Private cboFilter As New ComboBox()
    Private cboSort As New ComboBox()
    Private lblCount As New Label()
    Private lblCartCount As New Label()

    ' Top panels — declared at class level so we can reference them
    Private pnlHeader As New Panel()
    Private pnlFilter As New Panel()
    Private pnlScroll As New Panel()

    Private Sub InitForm() Handles MyBase.Load
        Me.Text = "GHC Pet Mart - Shop"
        Me.Size = New Size(1150, 700)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.WindowState = FormWindowState.Maximized
        Me.BackColor = Color.WhiteSmoke

        ' Handle resize so cards reflow
        AddHandler Me.Resize, AddressOf OnResize

        BuildHeader()
        BuildFilterBar()
        BuildProductArea()
        LoadCategories()
        LoadProducts()
        RefreshCartCount()
    End Sub

    ' ── Called every time form resizes ──────────────────────
    Private Sub OnResize(sender As Object, e As EventArgs)
        ' Header stretches full width
        pnlHeader.Width = Me.ClientSize.Width

        ' Filter bar stretches full width
        pnlFilter.Width = Me.ClientSize.Width

        ' Scroll panel fills the rest of the height and width
        pnlScroll.Width = Me.ClientSize.Width
        pnlScroll.Height = Me.ClientSize.Height - pnlHeader.Height - pnlFilter.Height

        ' FlowLayoutPanel fills the scroll panel
        flpProducts.Width = pnlScroll.ClientSize.Width - 20
    End Sub

    Private Sub BuildHeader()
        pnlHeader.Size = New Size(Me.ClientSize.Width, 65)
        pnlHeader.Location = New Point(0, 0)
        pnlHeader.BackColor = Color.FromArgb(40, 40, 80)
        pnlHeader.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right

        Dim lblLogo As New Label() With {
            .Text = "GHC PET MART",
            .Font = New Font("Arial", 16, FontStyle.Bold),
            .ForeColor = Color.White,
            .AutoSize = True,
            .Location = New Point(20, 18)
        }
        pnlHeader.Controls.Add(lblLogo)

        Dim lblWelcome As New Label() With {
            .Text = "Hello, " & LoggedFullName,
            .Font = New Font("Arial", 9),
            .ForeColor = Color.LightGray,
            .AutoSize = True,
            .Location = New Point(300, 24)
        }
        pnlHeader.Controls.Add(lblWelcome)

        ' Cart button — anchored to right
        Dim btnCart As New Button() With {
            .Text = "",
            .Size = New Size(130, 38),
            .BackColor = Color.FromArgb(76, 175, 80),
            .ForeColor = Color.White,
            .FlatStyle = FlatStyle.Flat,
            .Font = New Font("Arial", 10, FontStyle.Bold),
            .Anchor = AnchorStyles.Top Or AnchorStyles.Right
        }
        lblCartCount = New Label() With {
            .Text = "Cart (0)",
            .AutoSize = True,
            .ForeColor = Color.White,
            .Font = New Font("Arial", 10, FontStyle.Bold),
            .Location = New Point(10, 10)
        }
        btnCart.Controls.Add(lblCartCount)
        AddHandler btnCart.Click, Sub(s, e)
                                      Dim f As New frmCart()
                                      f.CustomerUserID = LoggedUserID
                                      f.ShowDialog()
                                      RefreshCartCount()
                                  End Sub

        Dim btnOrders As New Button() With {
            .Text = "My Orders",
            .Size = New Size(110, 38),
            .BackColor = Color.FromArgb(63, 81, 181),
            .ForeColor = Color.White,
            .FlatStyle = FlatStyle.Flat,
            .Anchor = AnchorStyles.Top Or AnchorStyles.Right
        }
        AddHandler btnOrders.Click, Sub(s, e)
                                        Dim f As New frmOrderHistory()
                                        f.CustomerUserID = LoggedUserID
                                        f.ShowDialog()
                                    End Sub

        Dim btnLogout As New Button() With {
            .Text = "Logout",
            .Size = New Size(85, 38),
            .BackColor = Color.FromArgb(244, 67, 54),
            .ForeColor = Color.White,
            .FlatStyle = FlatStyle.Flat,
            .Anchor = AnchorStyles.Top Or AnchorStyles.Right
        }
        AddHandler btnLogout.Click, Sub(s, e)
                                        Dim f As New frmLogin()
                                        f.Show()
                                        Me.Close()
                                    End Sub

        ' Position buttons relative to right side
        AddHandler pnlHeader.Resize, Sub(s, e)
                                         btnLogout.Location = New Point(pnlHeader.Width - 100, 13)
                                         btnOrders.Location = New Point(pnlHeader.Width - 225, 13)
                                         btnCart.Location = New Point(pnlHeader.Width - 370, 13)
                                     End Sub

        pnlHeader.Controls.Add(btnCart)
        pnlHeader.Controls.Add(btnOrders)
        pnlHeader.Controls.Add(btnLogout)
        Me.Controls.Add(pnlHeader)
    End Sub

    Private Sub BuildFilterBar()
        pnlFilter.Size = New Size(Me.ClientSize.Width, 50)
        pnlFilter.Location = New Point(0, pnlHeader.Height)
        pnlFilter.BackColor = Color.White
        pnlFilter.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right

        Dim lS As New Label() With {
            .Text = "Search:",
            .AutoSize = True,
            .Location = New Point(15, 15)
        }
        pnlFilter.Controls.Add(lS)

        txtSearch.Size = New Size(220, 28)
        txtSearch.Location = New Point(68, 12)
        pnlFilter.Controls.Add(txtSearch)

        Dim btnS As New Button() With {
            .Text = "Search",
            .Size = New Size(80, 28),
            .Location = New Point(298, 12),
            .BackColor = Color.FromArgb(63, 81, 181),
            .ForeColor = Color.White,
            .FlatStyle = FlatStyle.Flat
        }
        AddHandler btnS.Click, Sub(s, e) LoadProducts()
        pnlFilter.Controls.Add(btnS)

        Dim lF As New Label() With {
            .Text = "Filter by:",
            .AutoSize = True,
            .Location = New Point(400, 15)
        }
        pnlFilter.Controls.Add(lF)

        cboFilter.Location = New Point(465, 12)
        cboFilter.Size = New Size(180, 28)
        cboFilter.DropDownStyle = ComboBoxStyle.DropDownList
        AddHandler cboFilter.SelectedIndexChanged, Sub(s, e) LoadProducts()
        pnlFilter.Controls.Add(cboFilter)

        Dim lSo As New Label() With {
            .Text = "Sort by:",
            .AutoSize = True,
            .Location = New Point(660, 15)
        }
        pnlFilter.Controls.Add(lSo)

        cboSort.Location = New Point(715, 12)
        cboSort.Size = New Size(180, 28)
        cboSort.DropDownStyle = ComboBoxStyle.DropDownList
        cboSort.Items.AddRange(New String() {"Name A-Z", "Price Low-High", "Price High-Low"})
        cboSort.SelectedIndex = 0
        AddHandler cboSort.SelectedIndexChanged, Sub(s, e) LoadProducts()
        pnlFilter.Controls.Add(cboSort)

        lblCount.AutoSize = True
        lblCount.Font = New Font("Arial", 9, FontStyle.Bold)
        lblCount.Location = New Point(915, 17)
        pnlFilter.Controls.Add(lblCount)

        Me.Controls.Add(pnlFilter)
    End Sub

    Private Sub BuildProductArea()
        ' Scroll panel fills remaining space — DOCKED to fill
        pnlScroll.Location = New Point(0, pnlHeader.Height + pnlFilter.Height)
        pnlScroll.Size = New Size(
            Me.ClientSize.Width,
            Me.ClientSize.Height - pnlHeader.Height - pnlFilter.Height)
        pnlScroll.AutoScroll = True
        pnlScroll.BackColor = Color.WhiteSmoke
        pnlScroll.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or
                            AnchorStyles.Left Or AnchorStyles.Right

        flpProducts.Location = New Point(5, 5)
        flpProducts.Size = New Size(pnlScroll.ClientSize.Width - 20, 2000)
        flpProducts.AutoScroll = False
        flpProducts.WrapContents = True
        flpProducts.FlowDirection = FlowDirection.LeftToRight
        flpProducts.AutoSize = True
        flpProducts.AutoSizeMode = AutoSizeMode.GrowAndShrink

        pnlScroll.Controls.Add(flpProducts)
        Me.Controls.Add(pnlScroll)
    End Sub

    Private Sub LoadCategories()
        If Not OpenConnection() Then Return
        Try
            Dim da As New MySqlDataAdapter(
                "SELECT category_name FROM tbl_categories ORDER BY category_name", conn)
            Dim dt As New DataTable()
            da.Fill(dt)
            cboFilter.Items.Clear()
            cboFilter.Items.Add("All Categories")
            For Each row As DataRow In dt.Rows
                cboFilter.Items.Add(row("category_name").ToString())
            Next
            cboFilter.SelectedIndex = 0
        Finally
            CloseConnection()
        End Try
    End Sub

    Private Sub LoadProducts()
        flpProducts.Controls.Clear()

        If Not OpenConnection() Then Return
        Try
            Dim search As String = "%" & txtSearch.Text.Trim() & "%"
            Dim orderBy As String = "p.product_name ASC"
            Select Case cboSort.Text
                Case "Price Low-High" : orderBy = "p.regular_price ASC"
                Case "Price High-Low" : orderBy = "p.regular_price DESC"
            End Select

            Dim sql As String =
                "SELECT p.product_id, p.product_name, c.category_name, " &
                "p.regular_price, p.sale_price, p.stock_quantity, p.status " &
                "FROM tbl_products p " &
                "JOIN tbl_categories c ON p.category_id = c.category_id " &
                "WHERE p.product_name LIKE @s AND p.status <> 'Discontinued'"

            If cboFilter.SelectedIndex > 0 Then
                sql &= " AND c.category_name = '" & cboFilter.Text.Replace("'", "''") & "'"
            End If
            sql &= " ORDER BY " & orderBy

            Dim cmd As New MySqlCommand(sql, conn)
            cmd.Parameters.AddWithValue("@s", search)
            Dim dt As New DataTable()
            Dim da As New MySqlDataAdapter(cmd)
            da.Fill(dt)

            lblCount.Text = "No. of Products: " & dt.Rows.Count

            For Each row As DataRow In dt.Rows
                flpProducts.Controls.Add(CreateProductCard(row))
            Next

        Finally
            CloseConnection()
        End Try
    End Sub

    Private Function CreateProductCard(row As DataRow) As Panel
        Dim pid As Integer = CInt(row("product_id"))
        Dim pname As String = row("product_name").ToString()
        Dim price As Decimal = Convert.ToDecimal(row("regular_price"))
        Dim salePrice As Decimal = Convert.ToDecimal(row("sale_price"))
        Dim status As String = row("status").ToString()
        Dim displayPrice As Decimal = If(salePrice > 0, salePrice, price)

        Dim card As New Panel() With {
            .Size = New Size(210, 260),
            .BackColor = Color.White,
            .BorderStyle = BorderStyle.FixedSingle,
            .Margin = New Padding(8)
        }

        ' Image placeholder
        Dim pic As New PictureBox() With {
            .Size = New Size(170, 120),
            .Location = New Point(20, 12),
            .SizeMode = PictureBoxSizeMode.Zoom,
            .BackColor = Color.FromArgb(240, 240, 240)
        }
        card.Controls.Add(pic)

        ' Product name
        Dim lblName As New Label() With {
            .Text = pname,
            .Font = New Font("Arial", 8, FontStyle.Bold),
            .Size = New Size(190, 36),
            .Location = New Point(10, 138),
            .TextAlign = ContentAlignment.MiddleCenter
        }
        card.Controls.Add(lblName)

        ' Price
        Dim lblPrice As New Label() With {
            .Text = "P " & displayPrice.ToString("N2"),
            .Font = New Font("Arial", 11, FontStyle.Bold),
            .ForeColor = Color.FromArgb(63, 81, 181),
            .AutoSize = True,
            .Location = New Point(55, 175)
        }
        card.Controls.Add(lblPrice)

        ' Status
        Dim lblStatus As New Label() With {
            .Text = status,
            .Font = New Font("Arial", 7),
            .ForeColor = If(status = "In Stock",
                           Color.FromArgb(76, 175, 80),
                           Color.Red),
            .AutoSize = True,
            .Location = New Point(78, 197)
        }
        card.Controls.Add(lblStatus)

        ' Add to Cart button
        Dim btnAdd As New Button() With {
            .Text = If(status = "In Stock", "Add to Cart", "Sold Out"),
            .Size = New Size(170, 32),
            .Location = New Point(20, 218),
            .BackColor = If(status = "In Stock",
                           Color.FromArgb(76, 175, 80),
                           Color.LightGray),
            .ForeColor = Color.White,
            .FlatStyle = FlatStyle.Flat,
            .Enabled = (status = "In Stock"),
            .Tag = pid
        }
        AddHandler btnAdd.Click, AddressOf AddToCartClick
        card.Controls.Add(btnAdd)

        Return card
    End Function

    Private Sub AddToCartClick(sender As Object, e As EventArgs)
        Dim btn As Button = DirectCast(sender, Button)
        Dim productID As Integer = CInt(btn.Tag)

        If Not OpenConnection() Then Return
        Try
            Dim chk As New MySqlCommand(
                "SELECT COUNT(*) FROM tbl_cart WHERE user_id=@uid AND product_id=@pid", conn)
            chk.Parameters.AddWithValue("@uid", LoggedUserID)
            chk.Parameters.AddWithValue("@pid", productID)

            If Convert.ToInt32(chk.ExecuteScalar()) > 0 Then
                Dim upd As New MySqlCommand(
                    "UPDATE tbl_cart SET quantity=quantity+1 " &
                    "WHERE user_id=@uid AND product_id=@pid", conn)
                upd.Parameters.AddWithValue("@uid", LoggedUserID)
                upd.Parameters.AddWithValue("@pid", productID)
                upd.ExecuteNonQuery()
            Else
                Dim ins As New MySqlCommand(
                    "INSERT INTO tbl_cart(user_id, product_id, quantity) VALUES(@uid,@pid,1)", conn)
                ins.Parameters.AddWithValue("@uid", LoggedUserID)
                ins.Parameters.AddWithValue("@pid", productID)
                ins.ExecuteNonQuery()
            End If

            CloseConnection()
            RefreshCartCount()
            MessageBox.Show("Added to cart!", "Success",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
            CloseConnection()
        End Try
    End Sub

    Private Sub RefreshCartCount()
        If Not OpenConnection() Then Return
        Try
            Dim cmd As New MySqlCommand(
                "SELECT IFNULL(SUM(quantity),0) FROM tbl_cart WHERE user_id=@uid", conn)
            cmd.Parameters.AddWithValue("@uid", LoggedUserID)
            Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
            lblCartCount.Text = "Cart (" & count & ")"
        Finally
            CloseConnection()
        End Try
    End Sub

End Class