﻿Imports MySql.Data.MySqlClient

Public Class frmReports

    Private cboType As New ComboBox()
    Private cboPeriod As New ComboBox()
    Private dtpFrom As New DateTimePicker()
    Private dtpTo As New DateTimePicker()
    Private dgv As New DataGridView()
    Private lblSummary As New Label()

    Private Sub InitForm() Handles MyBase.Load
        Me.Text = "Reports"
        Me.Size = New Size(1100, 660)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.BackColor = Color.WhiteSmoke

        Dim lblTitle As New Label() With {
            .Text = "Report Generation",
            .Font = New Font("Arial", 14, FontStyle.Bold),
            .AutoSize = True, .Location = New Point(15, 15)
        }
        Me.Controls.Add(lblTitle)

        Dim lT As New Label() With {.Text = "Report Type:", .AutoSize = True, .Location = New Point(15, 55)}
        Me.Controls.Add(lT)
        cboType.Location = New Point(100, 52) : cboType.Size = New Size(160, 28)
        cboType.DropDownStyle = ComboBoxStyle.DropDownList
        cboType.Items.AddRange(New String() {"Sales", "Inventory", "Customers", "Suppliers"})
        cboType.SelectedIndex = 0
        Me.Controls.Add(cboType)

        Dim lP As New Label() With {.Text = "Period:", .AutoSize = True, .Location = New Point(275, 55)}
        Me.Controls.Add(lP)
        cboPeriod.Location = New Point(320, 52) : cboPeriod.Size = New Size(130, 28)
        cboPeriod.DropDownStyle = ComboBoxStyle.DropDownList
        cboPeriod.Items.AddRange(New String() {"Daily", "Weekly", "Monthly", "Annual", "Custom"})
        cboPeriod.SelectedIndex = 0
        AddHandler cboPeriod.SelectedIndexChanged, AddressOf OnPeriodChange
        Me.Controls.Add(cboPeriod)

        Dim lF As New Label() With {.Text = "From:", .AutoSize = True, .Location = New Point(465, 55)}
        Me.Controls.Add(lF)
        dtpFrom.Location = New Point(500, 52) : dtpFrom.Size = New Size(140, 28)
        dtpFrom.Enabled = False
        Me.Controls.Add(dtpFrom)

        Dim lTo As New Label() With {.Text = "To:", .AutoSize = True, .Location = New Point(655, 55)}
        Me.Controls.Add(lTo)
        dtpTo.Location = New Point(675, 52) : dtpTo.Size = New Size(140, 28)
        dtpTo.Enabled = False
        Me.Controls.Add(dtpTo)

        Dim btnGen As New Button() With {
            .Text = "GENERATE", .Size = New Size(110, 28), .Location = New Point(830, 52),
            .BackColor = Color.FromArgb(63, 81, 181), .ForeColor = Color.White, .FlatStyle = FlatStyle.Flat
        }
        AddHandler btnGen.Click, AddressOf GenerateReport
        Me.Controls.Add(btnGen)

        lblSummary.AutoSize = True
        lblSummary.Font = New Font("Arial", 10, FontStyle.Bold)
        lblSummary.ForeColor = Color.FromArgb(63, 81, 181)
        lblSummary.Location = New Point(15, 92)
        Me.Controls.Add(lblSummary)

        dgv.Location = New Point(15, 120)
        dgv.Size = New Size(1060, 480)
        dgv.ReadOnly = True
        dgv.AllowUserToAddRows = False
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.BackgroundColor = Color.White
        Me.Controls.Add(dgv)
    End Sub

    Private Sub OnPeriodChange(sender As Object, e As EventArgs)
        Dim isCustom As Boolean = cboPeriod.Text = "Custom"
        dtpFrom.Enabled = isCustom
        dtpTo.Enabled = isCustom
    End Sub

    Private Sub GenerateReport(sender As Object, e As EventArgs)
        Dim dateFrom As String = ""
        Dim dateTo As String = ""

        Select Case cboPeriod.Text
            Case "Daily"
                dateFrom = DateTime.Now.ToString("yyyy-MM-dd")
                dateTo = dateFrom
            Case "Weekly"
                dateFrom = DateTime.Now.AddDays(-7).ToString("yyyy-MM-dd")
                dateTo = DateTime.Now.ToString("yyyy-MM-dd")
            Case "Monthly"
                dateFrom = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).ToString("yyyy-MM-dd")
                dateTo = DateTime.Now.ToString("yyyy-MM-dd")
            Case "Annual"
                dateFrom = New DateTime(DateTime.Now.Year, 1, 1).ToString("yyyy-MM-dd")
                dateTo = DateTime.Now.ToString("yyyy-MM-dd")
            Case "Custom"
                dateFrom = dtpFrom.Value.ToString("yyyy-MM-dd")
                dateTo = dtpTo.Value.ToString("yyyy-MM-dd")
        End Select

        If Not OpenConnection() Then Return
        Try
            Dim dt As New DataTable()
            Dim da As MySqlDataAdapter

            Select Case cboType.Text
                Case "Sales"
                    da = New MySqlDataAdapter(
    "SELECT
        s.receipt_no AS 'Receipt', s.sale_date AS 'Date', 
        COALESCE(CONCAT(c.first_name,' ',c.last_name),'Walk-in') AS 'Customer',
        u.full_name AS 'Employee',

        SUM(sd.quantity * sd.unit_price - sd.discount) AS 'Total',

        s.amount_paid AS 'Paid',

        (s.amount_paid -
            SUM(sd.quantity * sd.unit_price - sd.discount)
        ) AS 'Change'

    FROM tbl_sales s

    LEFT JOIN tbl_customers c
        ON s.customer_id = c.customer_id

    LEFT JOIN tbl_users u
        ON s.employee_id = u.user_id

    LEFT JOIN tbl_sale_details sd
        ON s.sale_id = sd.sale_id

    WHERE DATE(s.sale_date)
        BETWEEN '" & dateFrom & "' AND '" & dateTo & "'

    GROUP BY
        s.sale_id,
        s.receipt_no,
        s.sale_date,
        c.first_name,
        c.last_name,
        u.full_name,
        s.amount_paid

    ORDER BY s.sale_date DESC", conn)

                Case "Inventory"
                    da = New MySqlDataAdapter(
                        "SELECT p.product_name AS 'Product', c.category_name AS 'Category', " &
                        "p.stock_quantity AS 'Stock', p.reorder_level AS 'Min Level', " &
                        "p.regular_price AS 'Price', p.status AS 'Status' " &
                        "FROM tbl_products p JOIN tbl_categories c ON p.category_id=c.category_id " &
                        "ORDER BY p.product_name", conn)

                Case "Customers"
                    da = New MySqlDataAdapter(
                        "SELECT CONCAT(c.first_name,' ',c.last_name) AS 'Name', " &
                        "c.email AS 'Email', c.phone AS 'Phone', c.city AS 'City', " &
                        "c.pet_type AS 'Pet', c.created_at AS 'Registered' " &
                        "FROM tbl_customers c ORDER BY c.first_name", conn)

                Case Else
                    da = New MySqlDataAdapter(
                        "SELECT supplier_name AS 'Supplier', contact_person AS 'Contact', " &
                        "phone AS 'Phone', email AS 'Email', city AS 'City' " &
                        "FROM tbl_suppliers ORDER BY supplier_name", conn)
            End Select

            da.Fill(dt)
            dgv.DataSource = dt
            lblSummary.Text = cboType.Text & " Report  |  Period: " & cboPeriod.Text &
                              "  |  Records: " & dt.Rows.Count
        Finally
            CloseConnection()
        End Try
    End Sub

End Class