﻿Public Class frmSplash

    Dim counter As Integer = 0

    Private Sub frmSplash_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Size = New Size(600, 400)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.BackColor = Color.White


        Dim pic As New PictureBox
        pic.Size = New Size(100, 100)
        pic.Location = New Point(250, 40)
        pic.SizeMode = PictureBoxSizeMode.Zoom
        Me.Controls.Add(pic)

        Dim lblTitle As New Label
        lblTitle.Text = "GHC PET MART"
        lblTitle.Font = New Font("Arial", 22, FontStyle.Bold)
        lblTitle.AutoSize = True
        lblTitle.Location = New Point(170, 150)
        Me.Controls.Add(lblTitle)

        Dim lblTag As New Label
        lblTag.Text = "One Home for Fur, Feathers, and Fins."
        lblTag.Font = New Font("Arial", 10, FontStyle.Italic)
        lblTag.ForeColor = Color.Gray
        lblTag.AutoSize = True
        lblTag.Location = New Point(130, 190)
        Me.Controls.Add(lblTag)


        Dim prg As New ProgressBar
        prg.Name = "prgLoading"
        prg.Size = New Size(400, 18)
        prg.Location = New Point(100, 300)
        prg.Maximum = 100
        Me.Controls.Add(prg)

        Dim tmr As New Timer
        tmr.Interval = 30
        AddHandler tmr.Tick, Sub(s, ev)
                                 counter += 2
                                 prg.Value = Math.Min(counter, 100)
                                 If counter >= 100 Then
                                     tmr.Stop()
                                     Dim login As New frmLogin()
                                     login.Show()
                                     Me.Hide()
                                 End If
                             End Sub
        tmr.Start()
    End Sub

End Class